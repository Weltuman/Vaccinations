﻿using System;
using System.Windows;
using static WpfApp20.MainWindow;
using Word = Microsoft.Office.Interop.Word;

namespace WpfApp20
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public class Data 
        {
            public string Age { get; set; }
            public string Priv { get; set; }

        }
        private void KalenPriv_Click(object sender, RoutedEventArgs e)
        {
            Random rnd = new Random();
            int dni = rnd.Next(5,7);

            DateTime date = DateTime.Parse(Data1.Text);

            
            


            if (Name.Text == "")
            {
                MessageBox.Show("Поле Имени не может быть пустым", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else if (M.IsChecked == true)
            {
                var data = new Data { Age = Data1.Text, Priv = "Вирусного гепатита B" };
                DataGridTest.Items.Add(data);

                var data1 = new Data { Age = date.AddDays(dni).ToString("dd.MM.yyyy"), Priv = "Туберкулёза" };
                DataGridTest.Items.Add(data1);

                var data2 = new Data { Age = date.AddMonths(1).ToString("dd.MM.yyyy"), Priv = "Вирусного генетита В" };
                DataGridTest.Items.Add(data2);

                var data3 = new Data { Age = date.AddMonths(2).ToString("dd.MM.yyyy"), Priv = "Пневмококковой инфекции" };
                DataGridTest.Items.Add(data3);

                var data4 = new Data { Age = date.AddMonths(3).ToString("dd.MM.yyyy"), Priv = "Дифтерии, столбняка, коклюша,\nгемофильной инфекции, полиомеилита" };
                DataGridTest.Items.Add(data4);

                var data5 = new Data { Age = date.AddDays(13).AddMonths(4).ToString("dd.MM.yyyy"), Priv = "Пневмококковой инфекции, дифтерии,\n столбняка,коклюша,гемофильной инфекции,полиомиелита" };
                DataGridTest.Items.Add(data5);

                var data6 = new Data { Age = date.AddMonths(6).ToString("dd.MM.yyyy"), Priv = "Вирусного генетита В,дифтерии,\n столбняка,коклюша,гемофильной инфекции,полиомиелита" };
                DataGridTest.Items.Add(data6);


                var data7 = new Data { Age = date.AddMonths(12).ToString("dd.MM.yyyy"), Priv = "Вирусного генетита В,дифтерии,\n кори, эпидемического паротита" };
                DataGridTest.Items.Add(data7);


                var data8 = new Data { Age = date.AddMonths(18).ToString("dd.MM.yyyy"), Priv = "Дифтерии, столбняка,гемофильной\n инфекции,полиомиелита" };
                DataGridTest.Items.Add(data8);


                var data9 = new Data { Age = date.AddMonths(20).ToString("dd.MM.yyyy"), Priv = "Полиомиелита" };
                DataGridTest.Items.Add(data9);


                var data10 = new Data { Age = date.AddMonths(72).ToString("dd.MM.yyyy"), Priv = "Кори, эпидемического паротита" };
                DataGridTest.Items.Add(data10);

                var data11 = new Data { Age = date.AddMonths(84).ToString("dd.MM.yyyy"), Priv = "Туберкулёза, дифтерии, столбняка" };
                DataGridTest.Items.Add(data11);

                var data12 = new Data { Age = date.AddMonths(168).ToString("dd.MM.yyyy"), Priv = "Дифтерии, столбняка,полиомиелита" };
                DataGridTest.Items.Add(data12);
            }
            else if (D.IsChecked == true)
            {
                var data = new Data { Age = Data1.Text, Priv = "Вирусного гепатита B" };
                DataGridTest.Items.Add(data);

                var data1 = new Data { Age = date.AddDays(dni).ToString("dd.MM.yyyy"), Priv = "Туберкулёза" };
                DataGridTest.Items.Add(data1);

                var data2 = new Data { Age = date.AddMonths(1).ToString("dd.MM.yyyy"), Priv = "Вирусного генетита В" };
                DataGridTest.Items.Add(data2);

                var data3 = new Data { Age = date.AddMonths(2).ToString("dd.MM.yyyy"), Priv = "Пневмококковой инфекции" };
                DataGridTest.Items.Add(data3);

                var data4 = new Data { Age = date.AddMonths(3).ToString("dd.MM.yyyy"), Priv = "Дифтерии, столбняка, коклюша,\nгемофильной инфекции, полиомеилита" };
                DataGridTest.Items.Add(data4);

                var data5 = new Data { Age = date.AddDays(13).AddMonths(4).ToString("dd.MM.yyyy"), Priv = "Пневмококковой инфекции, дифтерии,\n столбняка,коклюша,гемофильной инфекции,полиомиелита" };
                DataGridTest.Items.Add(data5);

                var data6 = new Data { Age = date.AddMonths(6).ToString("dd.MM.yyyy"), Priv = "Вирусного генетита В,дифтерии,\n столбняка,коклюша,гемофильной инфекции,полиомиелита" };
                DataGridTest.Items.Add(data6);


                var data7 = new Data { Age = date.AddMonths(12).ToString("dd.MM.yyyy"), Priv = "Вирусного генетита В,дифтерии,\n кори, эпидемического паротита" };
                DataGridTest.Items.Add(data7);


                var data8 = new Data { Age = date.AddMonths(18).ToString("dd.MM.yyyy"), Priv = "Дифтерии, столбняка,гемофильной\n инфекции,полиомиелита" };
                DataGridTest.Items.Add(data8);


                var data9 = new Data { Age = date.AddMonths(20).ToString("dd.MM.yyyy"), Priv = "Полиомиелита" };
                DataGridTest.Items.Add(data9);


                var data10 = new Data { Age = date.AddMonths(72).ToString("dd.MM.yyyy"), Priv = "Кори, эпидемического паротита" };
                DataGridTest.Items.Add(data10);

                var data11 = new Data { Age = date.AddMonths(84).ToString("dd.MM.yyyy"), Priv = "Туберкулёза, дифтерии, столбняка" };
                DataGridTest.Items.Add(data11);

                var data13 = new Data { Age = date.AddMonths(156).ToString("dd.MM.yyyy"), Priv = "Краснуха" };
                DataGridTest.Items.Add(data13);

                var data12 = new Data { Age = date.AddMonths(168).ToString("dd.MM.yyyy"), Priv = "Дифтерии, столбняка,полиомиелита" };
                DataGridTest.Items.Add(data12);
            }
            else
            {
                MessageBox.Show("Вы не выбрали пол", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            

        }

        //private void ImportWord_Click(object sender, RoutedEventArgs e)
        //{
        //    Word.Document doc = null;
        //    Word.Application app = new Word.Application();
        //    object fileName = @"E:\Test.docx";
        //    object falseValue = false;
        //    object trueValue = true;
        //    object missing = Type.Missing;

        //    doc = app.Documents.Open(ref fileName);
        //    app.Selection.Find.ClearFormatting();
        //    app.Selection.Find.Replacement.ClearFormatting();

        //    object findText1 = "ФИО";
        //    object replaceWith1 = Name.Text;
        //    object replace1 = 2;

        //    app.Selection.Find.Execute(ref findText1, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing,ref replaceWith1,ref replace1,ref missing, ref missing, ref missing, ref missing);


        //    object findText2 = "Дата";
        //    object replaceWith2 = Data1.Text;
        //    object replace2 = 2;
        //    app.Selection.Find.Execute(ref findText1, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref replaceWith1, ref replace1, ref missing, ref missing, ref missing, ref missing);

        //    object findText3 = "Пол";
        //    object replaceWith3 = D.IsChecked;
        //    object replace3 = 2;
        //    app.Selection.Find.Execute(ref findText1, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref replaceWith1, ref replace1, ref missing, ref missing, ref missing, ref missing);


        //    object findText4 = "Прививки";
        //    object replaceWith4 = DataGridTest;
        //    object replace4 = 2;


        //    doc.SaveAs2(@"E:\Тест");
        //    app.Quit();
        //}
    }
}
